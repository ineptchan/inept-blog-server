Inner ZIP attachment test.
